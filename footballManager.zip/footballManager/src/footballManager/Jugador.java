package footballManager;
import java.util.Objects;
import java.util.Random;

public class Jugador extends Persona{
    private int dorsal;
    private int posicion;
    private int calidad;

    /*Para que no se apliquen a objetos de otras clases, ni que se haga la sobreescritura
    * de la función cambiarDePosicion.*/
    private static final Random r = new Random();

    public Jugador(String nombre, String apellido, String fechaNacimiento, int nivelMotivacion, double sueldoAnual, int posicion) {
        super(nombre, apellido, fechaNacimiento, nivelMotivacion, sueldoAnual);
        this.posicion = posicion;
        this.dorsal = 0;
    }

    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(String dorsal) {
        this.dorsal = Integer.parseInt(dorsal);
    }

    public int getPosicion() {
        return posicion;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    public int getCalidad() {
        return calidad;
    }

    public void setCalidad(int calidad) {
        this.calidad = calidad;
    }

    @Override
    public void entrenar() {
        super.entrenar();
        System.out.println("El jugador " + this.nombre + " también está entrenando...");
    }

    public void cambiarDePosicion(int posicion) {
        int nuevaPosicion = 0;
        if (r.nextInt(100) < 5){
            System.out.println(this.nombre + " cambia de posición de " + posicion + " a " + nuevaPosicion);
            this.posicion = nuevaPosicion;
            this.calidad++;
            System.out.println("Nueva calidad: " + this.calidad);
        } else {
            System.out.println(this.nombre + " no ha cambiado de posición");
        }
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Jugador jugador = (Jugador) o; //Lo convierte a "Jugador"
        return Objects.equals(nombre, jugador.dorsal);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, dorsal);
    }

    @Override
    public String toString() {
        return "Los datos del jugador son: " +
                "dorsal='" + this.dorsal + '\'' +
                ", posicion=" + this.posicion +
                ", calidad=" + this.calidad +
                ", nombre='" + this.nombre + '\'' +
                ", apellido='" + this.apellido + '\'' +
                ", fechaNacimiento='" + this.fechaNacimiento + '\'' +
                ", nivelMotivacion=" + this.nivelMotivacion +
                ", sueldoAnual=" + this.sueldoAnual;
    }
}