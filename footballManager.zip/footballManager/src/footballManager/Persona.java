package footballManager;

public abstract class Persona {
    protected String nombre;
    protected String apellido;
    protected String fechaNacimiento;
    protected int nivelMotivacion;
    protected double sueldoAnual;

    public Persona(String nombre, String apellido, String fechaNacimiento, int nivelMotivacion, double sueldoAnual) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNacimiento = fechaNacimiento;
        this.nivelMotivacion = nivelMotivacion;
        this.sueldoAnual = sueldoAnual;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public int getNivelMotivacion() {
        return nivelMotivacion;
    }

    public void setNivelMotivacion(int nivelMotivacion) {
        this.nivelMotivacion = nivelMotivacion;
    }

    public double getSueldoAnual() {
        return sueldoAnual;
    }

    public void setSueldoAnual(double sueldoAnual) {
        this.sueldoAnual = sueldoAnual;
    }

    public void entrenar(){
        System.out.println("La persona " + this.nombre + " está entrenando...");
    }

    @Override
    public String toString() {
        return "Los datos de la persona son: " +
                "nombre='" + this.nombre + '\'' +
                ", apellido='" + this.apellido + '\'' +
                ", fechaNacimiento='" + this.fechaNacimiento + '\'' +
                ", nivelMotivacion=" + this.nivelMotivacion +
                ", sueldoAnual=" + this.sueldoAnual;
    }
}