package footballManager;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.lang.*;

public class Main {
    public static void main(String[] args) {
        darMensajeBienvenida();
        cargandoLosDatos();
        int opcion;
        boolean salir;
        Scanner sc = new Scanner(System.in);
        ArrayList<Persona> mercadoFichajes = new ArrayList<>();
        ArrayList<Equipo> equiposCreados = new ArrayList<>();
        ArrayList<Equipo> equipos = new ArrayList<>();
        ArrayList<Jugador> jugadores = new ArrayList<>();

        salir = false;
        do {
            System.out.println("Menú");
            System.out.println("1. Ver clasificación de la liga actual");
            System.out.println("2. Gestionar equipo");
            System.out.println("3. Dar de alta un equipo");
            System.out.println("4. Dar de alta a los jugadores i/o entrenadores");
            System.out.println("5. Consultar datos de los equipos");
            System.out.println("6. Consultar datos de los jugadores de los equipos");
            System.out.println("7. Disputar nueva liga");
            System.out.println("8. Realizar sesión de entrenamiento (mercat fitxatges)");
            System.out.println("9. Transferir jugadores");
            System.out.println("10. Guardar datos de los equipos");
            System.out.println("0. Salir");
            System.out.print("Escoge una opcion: ");
            opcion = sc.nextInt();

            switch (opcion){
                case 1:
                    verClasificacionLiga(equiposCreados);
                    break;
                case 2:
                    gestionarEquipo(sc);
                    break;
                case 3:
                    equiposCreados = darAltaEquipo(equipos);
                    break;
                case 4:
                    darAltaJugadoresOEntrenadores(mercadoFichajes);
                    break;
                case 5:
                    consultarDatosEquipos(equiposCreados);
                    break;
                case 6:
                    consultarDatosJugadores(equiposCreados);
                    break;
                case 7:
                    disputarNuevaLiga();
                    break;
                case 8:
                    realizarEntrenamiento(mercadoFichajes);
                    break;
                case 9:
                    transferirJugadores(equiposCreados, sc);
                    break;
                case 10:
                    guardarDatosEquiposJugadores(equiposCreados);
                    break;
                case 0:
                    salir = true;
                    System.out.println("Muchas gracias por tu atención. Hasta la próxima!");
                    break;
            }
        }while (!salir);
    }

    private static void darMensajeBienvenida() {
        System.out.println("¡Bienvenidos, fanáticos del fútbol! ⚽🔥");
        System.out.println("Prepárense para disfrutar de jugadas espectaculares, goles increíbles y mucha emoción.");
        System.out.println("¡Que comience el espectáculo y que gane el mejor equipo!");
        System.out.println("¡A disfrutar del fútbol! 🙌🎉");
    }

    private static void cargandoLosDatos() {
        String[] entrenadores = new String[5];
        String[] jugadores = new String[25];

        String fileName = "src/files/mercat_fitxatges.txt";
        int indexEntrenadores = 0, indexJugadores = 0;

        try {
            BufferedReader br;
            br = new BufferedReader(new FileReader(fileName));
            String line;

            while ((line = br.readLine()) != null) {
                String[] datos = line.split(";");
                String tipo = datos[0];
                String nombre = datos[1];

                if (tipo.equals("E") && indexEntrenadores < entrenadores.length) {
                    entrenadores[indexEntrenadores++] = nombre;
                } else if (tipo.equals("J") && indexJugadores < jugadores.length) {
                    jugadores[indexJugadores++] = nombre;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: No se ha encontrado el archivo.");
        } catch (IOException e) {
            System.out.println("Error: No se ha podido leer el archivo.");
        }
    }

    private static void verClasificacionLiga(ArrayList<Equipo> equiposCreados) {
        if (equiposCreados == null || equiposCreados.isEmpty()) {
            System.out.println("No hay equipos registrados en la liga.");
        }

        List<Equipo> equipos = new ArrayList<>(equiposCreados);

        // Ordenar por puntos (de mayor a menor)
        equipos.sort(Comparator.comparingInt(Equipo::getPuntos).reversed());

        // Mostrar la clasificación con un formato adecuado
        System.out.println("Clasificación del equipo:");
        for (int i = 0; i < equipos.size(); i++) {
            Equipo equipo = equipos.get(i);
            System.out.println((i + 1) + ". " + equipo.getNombre() + " - " + equipo.getPuntos() + " puntos");
        }

    }

    private static void gestionarEquipo(Scanner sc) {
        HashMap<String, String> equipos = new HashMap<>();
        String nombreEquipo, nuevoPresidente, infoEquipo;
        boolean salirSubMenu;
        int opcion;

        System.out.print("Introduce el nombre del equipo: ");
        nombreEquipo = sc.nextLine().trim(); // Eliminamos espacios en blanco adicionales

        if (!equipos.containsKey(nombreEquipo)) {
            System.out.println("Error, el equipo no existe.");
        } else {
            salirSubMenu = false;
            do {
                System.out.println("\nMenú");
                System.out.println("1.- Dar de baja el equipo");
                System.out.println("2.- Modificar presidente/a");
                System.out.println("3.- Destituir entrenador/a");
                System.out.println("4.- Fichar jugador/a o entrenador/a");
                System.out.println("0.- Salir");
                System.out.print("Escoge una opción: ");

                if (!sc.hasNextInt()) {
                    System.out.println("Error: Debes introducir un número.");
                    sc.next(); // Consumir entrada inválida
                }

                opcion = sc.nextInt();
                sc.nextLine(); // Consumir el salto de línea pendiente

                switch (opcion) {
                    case 1:
                        System.out.println("El equipo " + nombreEquipo + " ha sido dado de baja.");
                        equipos.remove(nombreEquipo);
                        guardarEquiposAFichero(equipos);
                        salirSubMenu = true;
                        break;

                    case 2:
                        System.out.print("Introduce el nombre del nuevo presidente/a: ");
                        nuevoPresidente = sc.nextLine().trim();
                        infoEquipo = equipos.get(nombreEquipo);

                        if (infoEquipo != null) {
                            String[] datos = infoEquipo.split(";");
                            if (datos.length >= 2) {
                                String presidenteActual = datos[1].replace("Presidente: ", "").trim();
                                if (presidenteActual.equals(nuevoPresidente)) {
                                    System.out.println("Aviso: El presidente/a ya es " + nuevoPresidente);
                                } else {
                                    datos[1] = "Presidente: " + nuevoPresidente;
                                    equipos.put(nombreEquipo, String.join(";", datos));
                                    System.out.println("Presidente/a modificado correctamente.");
                                    guardarEquiposAFichero(equipos);
                                }
                            } else {
                                System.out.println("Error: Datos del equipo corruptos.");
                            }
                        } else {
                            System.out.println("Error: No se encontraron datos del equipo.");
                        }
                        break;

                    case 3:
                        System.out.println("Entrenador/a destituido/a. El equipo se queda sin entrenador/a.");
                        infoEquipo = equipos.get(nombreEquipo);

                        if (infoEquipo != null) {
                            String[] datos = infoEquipo.split(";");
                            if (datos.length >= 3) {
                                datos[2] = "Entrenador: (vacante)";
                                equipos.put(nombreEquipo, String.join(";", datos));
                                guardarEquiposAFichero(equipos);
                            } else {
                                System.out.println("Error: Datos del equipo corruptos.");
                            }
                        } else {
                            System.out.println("Error: No se encontraron datos del equipo.");
                        }
                        break;

                    case 4:
                        ficharJugadorOEntrenador(sc, equipos, nombreEquipo);
                        break;

                    case 0:
                        salirSubMenu = true;
                        System.out.println("Saliendo del submenú...");
                        break;

                    default:
                        System.out.println("Opción no válida.");
                        break;
                }
            } while (!salirSubMenu);
        }
    }

    private static void guardarEquiposAFichero(HashMap<String, String> equipos) {
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter("src/files/equipos.txt", false));
            for (String infoEquipo : equipos.values()) {
                bw.write(infoEquipo);
            }
            System.out.println("Equipos guardados correctamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar el fichero de equipos");
        } finally {
            try {
                bw.close();
            } catch (IOException e){
                System.out.println("Error de cierre del fichero");
            }
        }
    }

    private static void ficharJugadorOEntrenador(Scanner sc, HashMap<String, String> equipos, String nombreEquipo) {
        int tipo, eleccion;
        String fichado;

        if (!equipos.containsKey(nombreEquipo)) {
            System.out.println("El equipo no existe.");
            // Si el equipo no existe, salimos del metodo.
        }

        System.out.print("¿Quieres fichar un (1) jugador o (2) entrenador? ");
        tipo = sc.nextInt();
        sc.nextLine();

        // Comprobamos que la entrada de tipo sea válida
        if (tipo != 1 && tipo != 2) {
            System.out.println("Selección no válida.");
        }

        List<String> disponibles = new ArrayList<>();
        for (String persona : equipos.keySet()) {
            if ((tipo == 1 && persona.equals("Jugador:")) || (tipo == 2 && persona.equals("Entrenador:"))) {
                disponibles.add(persona);
            }
        }

        if (disponibles.isEmpty()) {
            System.out.println("No hay disponibles en el mercado.");
            // Si no hay disponibles, salimos del metodo.
        }

        System.out.println("Lista de disponibles:");
        for (int i = 0; i < disponibles.size(); i++) {
            System.out.println((i + 1) + ". " + disponibles.get(i));
        }

        System.out.print("Elige el número de la persona que quieres fichar: ");
        eleccion = sc.nextInt();
        sc.nextLine();  // Limpiar el buffer de entrada

        if (eleccion < 1 || eleccion > disponibles.size()) {
            System.out.println("Selección no válida.");
            // Si la elección no es válida, salimos del metodo.
        }

        fichado = disponibles.get(eleccion - 1);
        equipos.remove(fichado);  // Eliminamos el fichado del mercado

        String infoEquipo = equipos.get(nombreEquipo);
        String[] datos = infoEquipo.split(";");

        if (tipo == 1) {
            // Asumimos que la posición 3 es para los jugadores
            datos[3] += " " + fichado.split(": ")[1];
        } else {
            // Asumimos que la posición 2 es para el entrenador
            datos[2] = "Entrenador: " + fichado.split(": ")[1];
        }

        equipos.put(nombreEquipo, String.join(";", datos));

        System.out.println(fichado + " ha sido fichado por " + nombreEquipo);
    }

    private static ArrayList<Equipo> darAltaEquipo(ArrayList<Equipo> equipos) {
        boolean equipoExiste;
        String nombreEquipo;
        String anyoFundacion;
        String ciudad;
        String estadio;
        String nombrePresidente;
        String nombreEntrenador;

        // Pedir el nombre del equipo asegurándonos de que no existe
        equipoExiste = false;
        do {
            System.out.print("Introduce el nombre del nuevo equipo: ");
            nombreEquipo = Teclat.llegirString();

            for (Equipo equipo : equipos) {
                if (nombreEquipo.equals(equipo.getNombre())) {
                    equipoExiste = true;
                    System.out.println("El equipo ya existe. Introduce otro nombre.");
                }
            }
        } while (equipoExiste);

        // Pedir el resto de los datos del equipo
        System.out.print("Introduce el año de fundación del equipo: ");
        anyoFundacion = Teclat.llegirString();

        System.out.print("Introduce la ciudad del equipo: ");
        ciudad = Teclat.llegirString();

        System.out.print("Introduce el estadio del equipo: ");
        estadio = Teclat.llegirString();

        System.out.print("Introduce el nombre del presidente del equipo: ");
        nombrePresidente = Teclat.llegirString();

        System.out.print("Introduce el nombre del entrenador del equipo: ");
        nombreEntrenador = Teclat.llegirString();

        // Crear y añadir el nuevo equipo
        Equipo nuevoEquipo = new Equipo(nombreEquipo, anyoFundacion, ciudad, estadio, nombrePresidente,
                nombreEntrenador, 0);
        equipos.add(nuevoEquipo);

        System.out.println("El equipo se ha añadido correctamente.");
        System.out.println(nuevoEquipo);

        // Guardar los datos del equipo en un fichero txt
        try {
            String datosEquipo = String.valueOf(nuevoEquipo);
            Path ruta = Paths.get("src/files/equipos.txt");
            Files.writeString(ruta, datosEquipo);
            System.out.println("El equipo se ha guardado correctamente en el archivo.");
        } catch (IOException e) {
            System.out.println("Error de escritura del equipo");
        }

        return equipos;
    }

    private static void darAltaJugadoresOEntrenadores(ArrayList<Persona> mercadoFichajes) {
        int opcion;
        boolean salirAltaJugadoresOEntrenadores;

        salirAltaJugadoresOEntrenadores = false;
        do {
            System.out.println("Dar de alta a los jugadores y/o entrenadores: ");
            System.out.println("1. Crear jugador/a");
            System.out.println("2. Crear entrenador/a");
            System.out.println("0. Salir");
            System.out.print("Escoge una opción: ");
            opcion = Teclat.llegirInt();

            switch (opcion) {
                case 1:
                    crearJugador(mercadoFichajes);
                    break;
                case 2:
                    crearEntrenador(mercadoFichajes);
                    break;
                case 0:
                    salirAltaJugadoresOEntrenadores = true;
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción no válida. Por favor, elige una opción válida.");
                    break;
            }
        } while (!salirAltaJugadoresOEntrenadores);
    }

    private static void crearJugador(ArrayList<Persona> mercadoFichajes) {
        String nombre;
        String apellido;
        String fechaNacimiento;
        int nivelMotivacion = 5;
        double sueldoAnual;
        int posicion;
        int calidad;
        int dorsal;
        Random r = new Random();

        System.out.println("Introduce los datos del jugador: ");
        System.out.print("Nombre: ");
        nombre = Teclat.llegirString();

        System.out.print("Apellido: ");
        apellido = Teclat.llegirString();

        System.out.print("Fecha de nacimiento: ");
        fechaNacimiento = Teclat.llegirString();

        System.out.print("Sueldo anual: ");
        sueldoAnual = Teclat.llegirDouble();

        System.out.print("Introduce la posición del jugador (1.POR, 2.DEF, 3.MIG, 4.DEL): ");
        posicion = Teclat.llegirInt();

        // Generar la calidad aleatoria entre 1 y 10
        calidad = r.nextInt(10) + 1;

        System.out.print("Introduce el dorsal: ");
        dorsal = Teclat.llegirInt();
        System.out.println();

        // Creamos al nuevo jugador con los datos introducidos
        Jugador nuevoJugador = new Jugador(nombre, apellido, fechaNacimiento, nivelMotivacion, sueldoAnual, posicion);
        nuevoJugador.setCalidad(calidad);

        // Añadir al jugador al mercado de fichajes
        mercadoFichajes.add(nuevoJugador);

        System.out.println("Jugador creado correctamente: ");
        System.out.println(nuevoJugador);

        try {
            String datosJugador = String.valueOf(nuevoJugador) + dorsal;
            Path ruta = Paths.get("src/files/jugadores.txt");
            Files.writeString(ruta, datosJugador);
        } catch (IOException e) {
            System.out.println("Error de escritura de jugadores");
        }
    }

    private static void crearEntrenador(ArrayList<Persona> mercadoFichajes) {
        String nombre;
        String apellido;
        String fechaNacimiento;
        int nivelMotivacion = 5;  // Nivel de motivación predeterminado
        double sueldoAnual;
        int torneosGanados;
        boolean esSeleccionador;

        System.out.println("Introduce los datos del entrenador: ");
        System.out.print("Nombre: ");
        nombre = Teclat.llegirString();

        System.out.print("Apellido: ");
        apellido = Teclat.llegirString();


        System.out.print("Fecha de nacimiento: ");
        fechaNacimiento = Teclat.llegirString();


        System.out.print("Sueldo anual: ");
        sueldoAnual = Teclat.llegirDouble();


        System.out.print("Torneos ganados: ");
        torneosGanados = Teclat.llegirInt();


        System.out.print("¿Es seleccionador? (true/false): ");
        esSeleccionador = Teclat.llegirBoolean();


        // Creamos al nuevo entrenador con los datos introducidos
        Entrenador entrenador = new Entrenador(nombre, apellido, fechaNacimiento, nivelMotivacion, sueldoAnual,
                torneosGanados, esSeleccionador);
        mercadoFichajes.add(entrenador);

        System.out.println("Entrenador creado correctamente");
        System.out.println(entrenador);

        try {
            String datosEntrenador = String.valueOf(entrenador);
            Path ruta = Paths.get("src/files/entrenadores.txt");
            Files.writeString(ruta, datosEntrenador);
        } catch (IOException e) {
            System.out.println("Error de escritura de los entrenadores");
        }
    }

    private static void consultarDatosEquipos(ArrayList<Equipo> equiposCreados) {
        for (int i = 0; i < equiposCreados.size(); i++) {
            if(equiposCreados.get(i) != null) {
                String file = "src/files/equipos.txt";
                BufferedReader br;
                try {
                    br = new BufferedReader(new FileReader(file));
                    while(br.readLine() != null){
                        System.out.println(equiposCreados.get(i));
                    }
                } catch (FileNotFoundException e) {
                    System.out.println("Error!! No se ha encontrado el fichero");
                } catch (IOException e) {
                    System.out.println("Error!! No se ha leído el fichero");
                }
            }
        }
    }

    private static void consultarDatosJugadores(ArrayList<Equipo> equiposCreados) {
        for (int i = 0; i < equiposCreados.size(); i++) {
            String nombreJugador;
            System.out.print("Nombre del jugador: ");
            nombreJugador = Teclat.llegirString();

            if(nombreJugador.equals(equiposCreados.get(i).getNombre())) {
                String fileName = "src/files/jugadores.txt";
                BufferedReader read = null;
                String linea;
                try {
                    read = new BufferedReader(new BufferedReader(new FileReader(fileName)));
                    while((linea = read.readLine()) != null){
                        System.out.println(linea);
                    }
                } catch (FileNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (IOException e) {
                    System.out.println("Error de lectura");
                } finally {
                    try {
                        read.close();
                    } catch (IOException e) {
                        System.out.println("Error de cierre");
                    }
                }
            }
        }
    }
    private static void disputarNuevaLiga() {
        Scanner sc = new Scanner(System.in);
        String nombreLiga;
        int numEquipos;
        String nombreEquipo;

        // Crear la liga
        System.out.print("Nombre de la liga: ");
        nombreLiga = sc.nextLine();
        Liga liga = new Liga(nombreLiga);  // Crear la liga con el nombre proporcionado

        // Añadir equipos
        System.out.print("Número de equipos: ");
        numEquipos = sc.nextInt();

        // Comprobar que el número de equipos sea válido (por ejemplo, al menos 2 equipos)
        if (numEquipos < 2) {
            System.out.println("Debe haber al menos 2 equipos para disputar la liga.");
        }

        sc.nextLine();  // Salto de línea

        for (int i = 0; i < numEquipos; i++) {
            System.out.print("Nombre del equipo " + (i + 1) + ": ");
            nombreEquipo = sc.nextLine();
            Equipo equipo = new Equipo(nombreEquipo);
            liga.anyadirEquipo(equipo);
        }

        // Si no hay equipos, no se puede disputar la liga
        if (liga.getEquipos().isEmpty()) {
            System.out.println("No hay equipos en la liga. No se puede disputar.");
        }

        // Generar y disputar la liga
        liga.generarPartidos();
        liga.disputarLiga();

        // Mostrar clasificación de la liga
        System.out.println("Clasificación de esta liga: ");
        liga.mostrarClasificacion();
    }

    private static void realizarEntrenamiento(List<Persona> mercadoFichajes) {
        // Recorremos todas las personas en el mercado de fichajes
        for (Persona persona : mercadoFichajes) {
            // Llamamos al metodo entrenar() en la persona (asumimos que está implementado en Persona o sus subclases)
            persona.entrenar();

            // Polimorfismo
            if (persona instanceof Jugador) {
                ((Jugador) persona).cambiarDePosicion(5);
            } else if (persona instanceof Entrenador) {
                ((Entrenador) persona).incrementarSueldo();
            }
        }

        System.out.println("Sesión de entrenamiento finalizada para los jugadores y para los entrenadores");
    }

    private static void transferirJugadores(ArrayList<Equipo> equiposCreados, Scanner sc) {
        //Equipos
        String equipoOrigenNombre;
        String equipoDestinoNombre;

        System.out.print("Introduce el nombre del equipo origen: ");
        equipoOrigenNombre = sc.nextLine();

        System.out.print("Introduce el nombre del equipo destino: ");
        equipoDestinoNombre = sc.nextLine();

        //Buscar equipos por su nombre
        Equipo equipoOrigen = null;
        Equipo equipoDestino = null;

        for(Equipo equipo : equiposCreados) {
            if(equipo.getNombre().equals(equipoOrigenNombre)) {
                equipoOrigen = equipo;
            } else if(equipo.getNombre().equals(equipoDestinoNombre)) {
                equipoDestino = equipo;
            }
        }

        //Verificación de los equipos (si existen)
        if (equipoOrigen == null){
            System.out.println("El nombre del equipo origen no existe");
        } else if (equipoDestino == null){
            System.out.println("El nombre del equipo destino no existe");
        }

        //Jugadores
        String nombreJugador;
        int dorsal;

        System.out.print("Introduce el nombre del jugador al que quieras transferir: ");
        nombreJugador = sc.nextLine();

        System.out.print("Introduce el dorsal del jugador al que quieras transferir: ");
        dorsal = sc.nextInt();

        //Buscar el jugador en el equipo origen
        Jugador jugadorATransferir = null;
        for(Jugador j : equipoOrigen.getJugadores()){
            if(j.getNombre().equalsIgnoreCase(nombreJugador) && j.getDorsal() == dorsal) {
                jugadorATransferir = j;
            }
        }

        if(jugadorATransferir == null){
            System.out.println("No se encuentra el jugador en el equipo origen");
        }

        //Transferencia
        equipoOrigen.getJugadores().remove(jugadorATransferir);
        equipoDestino.getJugadores().add(jugadorATransferir);

        System.out.println("El jugador " + jugadorATransferir.getNombre() + " ha sido transferido");

        //Keep all in a file
        guardarDatosEquiposJugadores(equiposCreados);
    }

    private static void guardarDatosEquiposJugadores(ArrayList<Equipo> equipos) {
        String dataFile = "src/files/data.txt";
        BufferedWriter bw = null;
        try {
            bw = new BufferedWriter(new FileWriter(dataFile));
            for (Equipo equipo : equipos) {
                bw.write("Equipo: " + equipo.getNombre() + "\n");
                bw.write("Año de fundación: " + equipo.getAnyoFundacion() + "\n");
                bw.write("Ciudad: " + equipo.getCiudad() + "\n");
                bw.write("Estadio: " + equipo.getEstadio() + "\n");
                bw.write("Presidente: " + equipo.getNombrePresidente() + "\n");
                bw.write("Entrenador: " + equipo.getNombreEntrenador() + "\n");
                bw.write("Puntos: " + equipo.getPuntos() + "\n");
                bw.write("Jugadores:\n");

                for (Jugador j : equipo.getJugadores()) {
                    bw.write(j.getNombre() + "\n");
                }
            }
            System.out.println("Los datos se han guardado correctamente.");
        } catch (IOException e) {
            System.out.println("Error al guardar los datos.");
        } finally{
            try {
                bw.close();
            } catch(IOException e){
                System.out.println("Error al cerrar los datos.");
            }
        }
    }
}