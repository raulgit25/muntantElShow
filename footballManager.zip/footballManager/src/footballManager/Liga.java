package footballManager;
import java.util.*;

public class Liga {
    String nombre;
    String numeroEquipos;
    ArrayList<Equipo> equipos;

    public Liga(String nombre, String numeroEquipos, ArrayList<Equipo> equipos) {
        this.nombre = nombre;
        this.numeroEquipos = numeroEquipos;
        this.equipos = equipos;
    }

    public Liga(String nombreLiga) {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNumeroEquipos() {
        return numeroEquipos;
    }

    public void setNumeroEquipos(String numeroEquipos) {
        this.numeroEquipos = numeroEquipos;
    }

    public ArrayList<Equipo> getEquipos() {
        return equipos;
    }

    public void setEquipos(ArrayList<Equipo> equipos) {
        this.equipos = equipos;
    }

    public void anyadirEquipo(Equipo equipo) {
        if(!equipos.contains(equipo)){
            equipos.add(equipo);
            System.out.println("Equipo " + equipo.getNombre() + " ha sido añadido a la liga " + this.nombre);
        } else {
            System.out.println("El equipo " + equipo.getNombre() + " ya ha sido añadido a la liga " + this.nombre);
        }
    }

    public void disputarLiga(){
        for (int i = 0; i < equipos.size(); i++) {
            for (int j = i + 1; j < equipos.size(); j++) {
                generarPartidos();
            }
        }
    }

    public void obtenerEquipoConMasGolesAFavor(){
        equipos.sort(Comparator.comparingInt(Equipo::getPuntos).reversed());

        if (equipos.size() > 0){
            System.out.println("Equipo con más goles a favor: ");
            for(Equipo equipo : equipos){
                System.out.println(equipo.getNombre() + " ha metido " + equipo.getPuntos() + " goles");
            }
        } else {
            System.out.println("No hay equipos en la liga");
        }
    }

    public void mostrarClasificacion(){
        System.out.println("Clasificación de los equipos: ");
        for (int i = 0; i < equipos.size(); i++) {
            System.out.println(equipos.get(i).getPuntos());
        }
    }

    public void generarPartidos(){
        Equipo eq1 = null;
        Equipo eq2 = null;
        Random r = new Random();
        int resultado = r.nextInt(3);//0 -> Empate, 1-> Gana el eq1, 2-> Gana el eq2

        switch(resultado){
            case 0:
                System.out.println("Empate entre " + eq1.getNombre() + " y " + eq2.getNombre());
                break;
            case 1:
                System.out.println("El equipo " + eq1.getNombre() + " ha ganado contra el equipo " + eq2.getNombre());
                break;
            case 2:
                System.out.println("El equipo " + eq2.getNombre() + " ha ganado contra el equipo " + eq1.getNombre());
                break;
            default:
                System.out.println("Error, no se puede generar el partido");
                break;
        }
    }

    public void reiniciarLiga(){
        for(Equipo equipo : equipos){
            equipo.reiniciar();
        }
        System.out.println("La liga " + this.nombre + " ha sido reiniciada");
    }
}