package footballManager;

public class Entrenador extends Persona{
    private int torneosGanados;
    private boolean esSeleccionador;

    public Entrenador(String nombre, String apellido, String fechaNacimiento, int nivelMotivacion, double sueldoAnual, int torneosGanados, boolean esSeleccionador) {
        super(nombre, apellido, fechaNacimiento, nivelMotivacion, sueldoAnual);
        this.torneosGanados = torneosGanados;
        this.esSeleccionador = esSeleccionador;
    }

    public int getTorneosGanados() {
        return torneosGanados;
    }

    public void setTorneosGanados(int torneosGanados) {
        this.torneosGanados = torneosGanados;
    }

    public void incrementarSueldo(){
        this.sueldoAnual*=1.005; //Incremento del 0,5%
    }

    public boolean isEsSeleccionador() {
        return esSeleccionador;
    }

    public void setEsSeleccionador(boolean esSeleccionador) {
        this.esSeleccionador = esSeleccionador;
    }

    @Override
    public void entrenar() {
        System.out.println("El entrenador está entrenando su equipo de jugadores...");
    }

    @Override
    public String toString() {
        return "Los datos del entrenador son: " +
                "torneosGanados=" + this.torneosGanados +
                ", esSeleccionador=" + this.esSeleccionador +
                ", nombre='" + this.nombre + '\'' +
                ", apellido='" + this.apellido + '\'' +
                ", fechaNacimiento='" + this.fechaNacimiento + '\'' +
                ", nivelMotivacion=" + this.nivelMotivacion +
                ", sueldoAnual=" + this.sueldoAnual;
    }
}