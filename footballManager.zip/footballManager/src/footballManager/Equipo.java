package footballManager;
import java.util.*;

public class Equipo {
    private String nombre;
    private String anyoFundacion;
    private String ciudad;
    private String estadio;
    private String nombrePresidente;
    private String nombreEntrenador;
    private ArrayList<Jugador> jugadores;
    private int puntos;

    public Equipo(String nombre, String anyoFundacion, String ciudad, String estadio, String nombrePresidente, String nombreEntrenador, int puntos) {
        this.nombre = nombre;
        this.anyoFundacion = anyoFundacion;
        this.ciudad = ciudad;
        this.estadio = estadio;
        this.nombrePresidente = nombrePresidente;
        this.nombreEntrenador = nombreEntrenador;
        this.puntos = puntos;
    }

    public Equipo(String nombreEquipo) {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAnyoFundacion() {
        return anyoFundacion;
    }

    public void setAnyoFundacion(String anyoFundacion) {
        this.anyoFundacion = anyoFundacion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEstadio() {
        return estadio;
    }

    public void setEstadio(String estadio) {
        this.estadio = estadio;
    }

    public String getNombrePresidente() {
        return nombrePresidente;
    }

    public void setNombrePresidente(String nombrePresidente) {
        this.nombrePresidente = nombrePresidente;
    }

    public String getNombreEntrenador() {
        return nombreEntrenador;
    }

    public void setNombreEntrenador(String nombreEntrenador) {
        this.nombreEntrenador = nombreEntrenador;
    }

    public ArrayList<Jugador> getJugadores() {
        return jugadores;
    }

    public void setJugadores(ArrayList<Jugador> jugadores) {
        this.jugadores = jugadores;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public double calcularMediaCalidad(){
        double suma = 0;
        if(jugadores.isEmpty()){
            return 0.0;
        }
        for(Jugador jugador : jugadores){
            suma += jugador.getCalidad();
        }
        return suma / jugadores.size();
    }

    public void reiniciar(){
        this.puntos = 0;
    }

    @Override
    public String toString() {
        return "Los datos del equipo son: " +
                "nombre='" + this.nombre + '\'' +
                ", anyoFundacion='" + this.anyoFundacion + '\'' +
                ", ciudad='" + this.ciudad + '\'' +
                ", estadio='" + this.estadio + '\'' +
                ", nombrePresidente='" + this.nombrePresidente + '\'' +
                ", nombreEntrenador='" + this.nombreEntrenador + '\'' +
                ", jugadores=" + this.jugadores + '\'' +
                ", puntos=" + this.puntos;
    }
}